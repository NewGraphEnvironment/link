## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 6,
  dpi = 150,
  message = FALSE,
  warning = FALSE
)
library(link)

## ----params, echo = FALSE-----------------------------------------------------
params <- data.frame(
  species = c("BT", "GR"),
  configuration = c("bcfishpass (parity)", "default (link extension)"),
  access_grad_max = c(0.25, 0.15),
  spawn_grad_max = c(0.0549, 0.0249),
  rear_grad_max = c(0.1049, 0.0349),
  spawn_cw_min_m = c(2, 4),
  rear_cw_min_m = c(1.5, 1.5),
  stringsAsFactors = FALSE
)
knitr::kable(
  params, row.names = FALSE,
  col.names = c("species", "configuration", "access grad max",
                "spawn grad max", "rear grad max", "spawn CW min (m)",
                "rear CW min (m)"),
  caption = paste0(
    "Access, spawning, and rearing gradient ceilings and minimum channel ",
    "widths for the two species mapped in this vignette. Bull trout is ",
    "modelled by both bcfishpass and link's bcfishpass config (the parity ",
    "case); Arctic grayling is modelled only by link's default config (the ",
    "extension). Grayling's lower access ceiling (0.15 vs 0.25) and narrower ",
    "spawning/rearing gradient windows are what give it the smaller modelled ",
    "network seen below."
  )
)

## ----load, include = FALSE----------------------------------------------------
library(sf)

gpkg   <- system.file("vignette-data/pars.gpkg",   package = "link", mustWork = TRUE)
parity <- readRDS(system.file("vignette-data/pars_parity.rds",
                              package = "link", mustWork = TRUE))
accessible <- readRDS(system.file("vignette-data/pars_accessible.rds",
                                  package = "link", mustWork = TRUE))

present <- sf::st_layers(gpkg)$name
lyr <- function(name) {
  if (name %in% present) sf::st_read(gpkg, layer = name, quiet = TRUE) else NULL
}

aoi           <- lyr("aoi")
streams       <- lyr("streams")
waterbodies   <- lyr("waterbodies")
named_streams <- lyr("named_streams")
reserves      <- lyr("reserves")
parks         <- lyr("parks")
roads         <- lyr("roads")
railways      <- lyr("railways")

# Context layers (reserves/parks/roads/railways) are pulled by intersection
# with the WSG boundary, so whole features can spill past it. Clip them to the
# boundary shape so nothing renders outside the basin.
clip_aoi <- function(x) {
  if (is.null(x) || nrow(x) == 0L) return(x)
  out <- suppressWarnings(sf::st_intersection(x, sf::st_union(sf::st_geometry(aoi))))
  if (nrow(out) == 0L) NULL else out
}
roads    <- clip_aoi(roads)
railways <- clip_aoi(railways)
reserves <- clip_aoi(reserves)
parks    <- clip_aoi(parks)

# Classified-segment counts for the grayling map captions — derived from the
# loaded layer so they track the cached artifact, never hand-edited.
.bt_present <- !is.na(streams$mapping_code_bt) & nzchar(streams$mapping_code_bt)
.gr_present <- !is.na(streams$mapping_code_gr) & nzchar(streams$mapping_code_gr)
n_bt     <- sum(.bt_present)
n_gr     <- sum(.gr_present)
n_gronly <- sum(.gr_present & !.bt_present)

## ----model-run, eval = FALSE--------------------------------------------------
# conn <- lnk_db_conn()
# 
# cfg_bcfp <- lnk_config("bcfishpass")          # persists to schema `fresh`
# loaded   <- lnk_load_overrides(cfg_bcfp)
# lnk_pipeline_run(conn, aoi = "PARS", cfg = cfg_bcfp, loaded = loaded,
#                  mapping_code = TRUE)
# 
# cfg_default <- lnk_config("default")          # persists to `fresh_default`
# cfg_default$pipeline$schema <- "fresh_default"
# loaded_d <- lnk_load_overrides(cfg_default)
# lnk_pipeline_run(conn, aoi = "PARS", cfg = cfg_default, loaded = loaded_d,
#                  mapping_code = TRUE)

## ----parity-table, echo = FALSE-----------------------------------------------
ptab <- parity[, c("wsg", "species", "total_segs", "match_pct")]
names(ptab) <- c("WSG", "species", "segments", "match %")
knitr::kable(
  ptab, row.names = FALSE,
  caption = paste0(
    "Per-segment mapping_code parity for bull trout in PARS, link's ",
    "bcfishpass config vs the local bcfishpass snapshot."
  )
)

## ----parity-pct, echo = FALSE, results = "asis"-------------------------------
cat(sprintf(paste0("link reproduces **%.2f%%** of bcfishpass's per-segment ",
                   "bull-trout `mapping_code` across %s segments — consistent ",
                   "with the 99.66%% study-area median established for the ",
                   "Peace.\n"),
            parity$match_pct[1],
            format(parity$total_segs[1], big.mark = ",")))

## ----accessible-table, echo = FALSE-------------------------------------------
atab <- accessible
names(atab) <- c("metric", "link km", "bcfishpass km", "diff %")
knitr::kable(
  atab, row.names = FALSE, digits = 2,
  caption = paste0(
    "Bull-trout accessible / spawning / rearing habitat (km) in PARS: link's ",
    "roll-up vs the local bcfishpass snapshot. Accessible habitat matches to a ",
    "rounding error; spawning and rearing agree within the habitat model's ",
    "tolerance (both well inside the 5% parity band)."
  )
)

## ----accessible-pct, echo = FALSE, results = "asis"---------------------------
acc <- accessible[accessible$metric == "accessible", ]
cat(sprintf(paste0("link models **%s km** of accessible bull-trout habitat in ",
                   "PARS against bcfishpass's **%s km** — a **%+.2f%%** ",
                   "difference. Spawning and rearing agree within the habitat ",
                   "model's tolerance.\n"),
            formatC(acc$link_km, format = "f", digits = 1, big.mark = ","),
            formatC(acc$bcfp_km, format = "f", digits = 1, big.mark = ","),
            acc$diff_pct))

## ----symbology, include = FALSE-----------------------------------------------
reg <- gq::gq_reg_main()
cls <- gq::gq_tmap_classes(reg$layers$streams_salmon)

# bcfishpass line widths come from the same registry — habitat use drives line
# weight (SPAWN thick, REAR medium, ACCESS thin), barrier status drives colour.
# Stored raw here and scaled per map below (full-WSG views need thinner lines
# than the zoomed detail panels). Unmatched tokens fall to the thinnest weight.
width_for <- function(tokens) {
  w <- cls$widths[tokens]
  w[is.na(w)] <- min(cls$widths, na.rm = TRUE)
  unname(w)
}

# Legend labels are decoded from the mapping_code token rather than taken from
# cls$labels: the upstream QGIS project mislabels the ACCESS habitat token as
# "No known barriers" (colliding with token2's own status wording, producing
# "No known barriers; known barrier"). Fix-at-source tracked in the bcfishpass
# fork and gq registry; decoded here so the legend reads correctly meanwhile.
.tok1 <- c(SPAWN = "Spawning", REAR = "Rearing", ACCESS = "Accessible")
.tok2 <- c(NONE = "no known barriers", MODELLED = "potential barrier",
           ASSESSED = "known barrier", DAM = "dam", REMEDIATED = "remediated")
label_for <- function(tokens) {
  vapply(strsplit(tokens, ";", fixed = TRUE), function(p) {
    parts <- c(.tok1[p[1]], if (length(p) >= 2) .tok2[p[2]],
               if (length(p) >= 3 && p[3] == "INTERMITTENT") "intermittent")
    paste(parts[!is.na(parts)], collapse = "; ")
  }, character(1))
}

# Context layers shared by the two full-WSG maps, drawn UNDER the
# mapping_code streams: waterbodies, resource roads, railways, then the
# land-use polygons (parks, reserves) on top of hydro/transport so they read
# where they overlap — the flooded layering. Reserves are tiny at WSG scale,
# so each gets a centroid diamond marker.
draw_context_full <- function() {
  if (!is.null(waterbodies)) {
    plot(sf::st_geometry(waterbodies), col = "#a3cdb966", border = "#2171B5",
         lwd = 0.3, add = TRUE)
  }
  if (!is.null(roads)) {
    plot(sf::st_geometry(roads), col = "#88888888", lwd = 0.25, add = TRUE)
  }
  if (!is.null(railways)) {
    plot(sf::st_geometry(railways), col = "black", lwd = 0.8, lty = "dashed",
         add = TRUE)
  }
  if (!is.null(parks)) {
    plot(sf::st_geometry(parks), col = "#639b5f55", border = "#33a02c",
         lwd = 0.7, add = TRUE)
  }
}

# Reserves draw OVER the mapping_code streams (called after the stream plot),
# so the polygon + centroid diamond read where they overlap the network.
draw_reserves <- function(x, fill = "#b2b2b288", cex = 0.9) {
  if (is.null(x) || nrow(x) == 0L) return(invisible())
  plot(sf::st_geometry(x), col = fill, border = "#232323", lwd = 0.6,
       add = TRUE)
  pts <- suppressWarnings(sf::st_centroid(sf::st_geometry(x),
                                          of_largest_polygon = TRUE))
  plot(pts, pch = 23, bg = "#222222", col = "white", cex = cex, add = TRUE)
}

# Reserve english_name labels with a thin white halo, drawn last with
# xpd = TRUE so an edge label isn't cropped at the plot region.
label_reserves <- function(x, cex = 0.45) {
  if (is.null(x) || !"english_name" %in% names(x) || nrow(x) == 0L) {
    return(invisible())
  }
  pts <- suppressWarnings(sf::st_centroid(sf::st_geometry(x),
                                          of_largest_polygon = TRUE))
  coords <- sf::st_coordinates(pts)
  ofs_y  <- par("cxy")[2] * 0.45 * 0.9
  halo_x <- par("cxy")[1] * 0.45 * 0.05
  halo_y <- par("cxy")[2] * 0.45 * 0.05
  ly <- coords[, 2] - ofs_y
  for (dx in c(-1, 1)) {
    text(coords[, 1] + dx * halo_x, ly, labels = x$english_name,
         cex = cex, col = "white", font = 2, xpd = TRUE)
  }
  for (dy in c(-1, 1)) {
    text(coords[, 1], ly + dy * halo_y, labels = x$english_name,
         cex = cex, col = "white", font = 2, xpd = TRUE)
  }
  text(coords[, 1], ly, labels = x$english_name, cex = cex, col = "#111111",
       font = 2, xpd = TRUE)
}

# mapping_code legend drawn outside the plotting region (into the reserved
# right margin) so it never overlaps the network.
legend_mapping_code <- function(tokens) {
  present <- names(cls$values) %in% unique(tokens)
  toks <- names(cls$values)[present]
  key_lwd <- cls$widths[present] * 2
  # base R scales dash length by line width, so a thick "dashed" key fits only
  # ~1 dash in the short legend segment while thin keys show many. Give thicker
  # intermittent keys a finer pattern so all read as dashes at the same seg.len.
  is_int <- grepl(";INTERMITTENT", toks)
  key_lty <- ifelse(!is_int, "solid",
                    ifelse(key_lwd > 2.5, "22",
                           ifelse(key_lwd > 1.5, "33", "44")))
  legend("topright", inset = c(-0.34, 0), xpd = TRUE, title = "Legend",
         legend = label_for(toks), col = cls$values[present],
         lwd = key_lwd, lty = key_lty,
         seg.len = 3, cex = 0.55, bty = "n")
}

## ----map-bt, echo = FALSE, fig.cap = "Bull-trout per-segment mapping_code across the Parsnip River Watershed Group, link's bcfishpass configuration. Stream colours come straight from the bcfishpass symbology registry, so they match a bcfishpass QGIS project exactly. Context: lakes/rivers/manmade waterbodies (light blue), provincial parks (green), First Nations reserves (grey polygon + black diamond + label), resource roads (grey), railways (black dashed); the heavy black line is the watershed-group boundary."----
bt <- streams[!is.na(streams$mapping_code_bt) & nzchar(streams$mapping_code_bt), ]
bt$col <- cls$values[bt$mapping_code_bt]
bt$col[is.na(bt$col)] <- "#999999"
bt$w <- width_for(bt$mapping_code_bt)
bt$lty <- ifelse(grepl(";INTERMITTENT", bt$mapping_code_bt), "dashed", "solid")

op <- par(mar = c(2, 1, 4, 8))
plot(sf::st_geometry(aoi), col = NA, border = "black", lwd = 1.5, axes = FALSE,
     main = "PARS — bull trout mapping_code\n(link bcfishpass config)")
draw_context_full()
plot(sf::st_geometry(bt), col = bt$col, lwd = bt$w * 0.6, lty = bt$lty, add = TRUE)
plot(sf::st_geometry(aoi), col = NA, border = "black", lwd = 1.5, add = TRUE)
draw_reserves(reserves)
label_reserves(reserves)
legend_mapping_code(bt$mapping_code_bt)
par(op)

## ----map-gr, echo = FALSE, fig.cap = sprintf("Arctic grayling per-segment mapping_code across the Parsnip River Watershed Group, link's default configuration — a species bcfishpass does not yet model. Same symbology registry and context layers as the bull-trout map, so the two are directly comparable. The grayling network is smaller than bull trout's (%s vs %s classified segments), but every grayling segment is net-new output relative to bcfishpass, and %s of them carry no bull-trout classification at all.", format(n_gr, big.mark = ","), format(n_bt, big.mark = ","), format(n_gronly, big.mark = ","))----
gr <- streams[!is.na(streams$mapping_code_gr) & nzchar(streams$mapping_code_gr), ]
gr$col <- cls$values[gr$mapping_code_gr]
gr$col[is.na(gr$col)] <- "#999999"
gr$w <- width_for(gr$mapping_code_gr)
gr$lty <- ifelse(grepl(";INTERMITTENT", gr$mapping_code_gr), "dashed", "solid")

op <- par(mar = c(2, 1, 4, 8))
plot(sf::st_geometry(aoi), col = NA, border = "black", lwd = 1.5, axes = FALSE,
     main = "PARS — Arctic grayling mapping_code\n(link default config)")
draw_context_full()
plot(sf::st_geometry(gr), col = gr$col, lwd = gr$w * 0.6, lty = gr$lty, add = TRUE)
plot(sf::st_geometry(aoi), col = NA, border = "black", lwd = 1.5, add = TRUE)
draw_reserves(reserves)
label_reserves(reserves)
legend_mapping_code(gr$mapping_code_gr)
par(op)

## ----map-detail, echo = FALSE, fig.width = 7, fig.height = 4.5, fig.cap = "South-east corner of the Parsnip River Watershed Group at full resolution — the headwaters near the continental divide: bull trout (left, link bcfishpass config) and Arctic grayling (right, link default config), same extent, same symbology. Grey background streams are the full modelled network, so the coloured overlay shows where each species' classification reaches. Context: waterbodies (light blue), parks (green), reserves (grey + diamond), roads (grey), railways (black dashed), named streams (italic blue labels)."----
e <- sf::st_bbox(aoi)
inset_bbox <- sf::st_bbox(c(
  xmin = unname(e["xmin"] + (e["xmax"] - e["xmin"]) * 0.55),
  ymin = unname(e["ymin"]),
  xmax = unname(e["xmax"]),
  ymax = unname(e["ymin"] + (e["ymax"] - e["ymin"]) * 0.45)
), crs = sf::st_crs(aoi))

crop_sf <- function(x) {
  if (is.null(x) || nrow(x) == 0L) return(NULL)
  out <- suppressWarnings(sf::st_crop(x, inset_bbox))
  if (nrow(out) == 0L) NULL else out
}

frame <- sf::st_as_sfc(inset_bbox)
all_d   <- crop_sf(streams)
bt_d    <- crop_sf(bt)
gr_d    <- crop_sf(gr)
wb_d    <- crop_sf(waterbodies)
aoi_d   <- crop_sf(aoi)
roads_d <- crop_sf(roads)
rail_d  <- crop_sf(railways)
res_d   <- crop_sf(reserves)
parks_d <- crop_sf(parks)
ns_d    <- crop_sf(named_streams)

panel <- function(seg, title) {
  plot(sf::st_geometry(frame), col = NA, border = NA, axes = FALSE,
       main = title)
  if (!is.null(wb_d)) {
    plot(sf::st_geometry(wb_d), col = "#a3cdb988", border = "#2171B5",
         lwd = 0.4, add = TRUE)
  }
  if (!is.null(all_d)) {
    plot(sf::st_geometry(all_d), col = "#cccccc", lwd = 0.4, add = TRUE)
  }
  if (!is.null(roads_d)) {
    plot(sf::st_geometry(roads_d), col = "#666666aa", lwd = 0.4, add = TRUE)
  }
  if (!is.null(rail_d)) {
    plot(sf::st_geometry(rail_d), col = "black", lwd = 1.0, lty = "dashed",
         add = TRUE)
  }
  if (!is.null(parks_d)) {
    plot(sf::st_geometry(parks_d), col = "#639b5f55", border = "#33a02c",
         lwd = 0.8, add = TRUE)
  }
  if (!is.null(seg) && nrow(seg) > 0L) {
    plot(sf::st_geometry(seg), col = seg$col, lwd = seg$w, lty = seg$lty,
         add = TRUE)
  }
  draw_reserves(res_d, fill = "#b2b2b2aa", cex = 1.0)
  if (!is.null(aoi_d)) {
    plot(sf::st_geometry(aoi_d), border = "black", lwd = 1.5, add = TRUE)
  }
  if (!is.null(ns_d)) {
    dedup <- ns_d[!duplicated(ns_d$gnis_name), ]
    npts <- suppressWarnings(sf::st_centroid(sf::st_geometry(dedup)))
    text(sf::st_coordinates(npts), labels = dedup$gnis_name, cex = 0.45,
         font = 3, col = "#0d3a6c")
  }
}

op <- par(mfrow = c(1, 2), mar = c(1, 1, 2, 1))
panel(bt_d, "Bull trout")
panel(gr_d, "Arctic grayling")
par(op)

